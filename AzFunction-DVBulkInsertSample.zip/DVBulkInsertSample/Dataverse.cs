﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk.Messages;
using System.Threading;

namespace DVBulkInsertSample
{
    internal class Dataverse
    {
        public Dataverse(Input inputParams)
        {
            // Bump up the min threads reserved for this app to ramp connections faster - minWorkerThreads defaults to 4, minIOCP defaults to 4 
            ThreadPool.SetMinThreads(100, 100);
            //Change max connections from .NET to a remote service default: 2
            System.Net.ServicePointManager.DefaultConnectionLimit = 65000;
            //Bump up the min threads reserved for this app to ramp connections faster - minWorkerThreads defaults to 4, minIOCP defaults to 4
            System.Threading.ThreadPool.SetMinThreads(100, 100);
            //Turn off the Expect 100 to continue message - 'true' will cause the caller to wait until it round-trip confirms a connection to the server
            System.Net.ServicePointManager.Expect100Continue = false;
            //Can decrease overall transmission overhead but can cause delay in data packet arrival
            System.Net.ServicePointManager.UseNagleAlgorithm = false;
            //Updated for faster handshake
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            this.Params = inputParams;
        }

        internal ServiceClient GetClient(ILogger logger)
        {
            ServiceClient client = new ServiceClient(new Uri(this.Params.OrgUrl), this.Params.ClientId, this.Params.ClientSecret, false, logger);
            logger.LogInformation("Client Generated Successfully");

            return client;
        }

        public async Task DoInternalAsync1(ILogger logger, string activityId, int maxRetryCount)
        {
            logger.LogInformation("Long running operation started.");
            await Task.Delay(TimeSpan.FromSeconds(120));
            logger.LogInformation("Long running operation completed.");
        }
        
        public async Task DoInternalAsync(ILogger logger, string activityId, int maxRetryCount)
        {
            try
            {
                Stopwatch stopWatch = new Stopwatch();
                stopWatch.Start();
                int totalRecords = this.Params.Items.Count;
                logger.LogInformation($"Started-Watch {activityId} - StartedProcessing: {totalRecords} at {DateTime.Now} ");

                List<Entity> customEntityCollection = new List<Entity>();

                using (var client = this.GetClient(logger))
                {
                    client.EnableAffinityCookie = false;
                    client.SessionTrackingId = Guid.Parse(activityId);

                    logger.LogInformation($"MaxDop: {client.RecommendedDegreesOfParallelism} Dataverse Server");
                    int actualDop = this.Params.DoP == 0 ? client.RecommendedDegreesOfParallelism : this.Params.DoP;

                    Entity trackerEntity = null;
                    if(!(string.IsNullOrEmpty(this.Params.UploadId.ToString())))
                    {
                        try
                        {
                            trackerEntity = new Entity(Constants.UploadTable, this.Params.UploadId);
                            //update tracking table for ingestion start
                            trackerEntity[Constants.EntityAttributes.UploadTotalRecords] = this.Params.Items.Count;
                            trackerEntity[Constants.StatusColumn] = Constants.StatusValueInserting;
                            trackerEntity[Constants.IngestionStartColumn] = DateTime.Now;
                            client.Update(trackerEntity);
                            logger.LogInformation($"Updated tracker table: {Constants.UploadTable}, Id = {this.Params.UploadId}");
                        }
                        catch(Exception ex) {
                            //trackerEntity fails
                            trackerEntity = null;
                            logger.LogError($"Error trying to update tracker entity. Ingestion will proceed without updating tracker. {ex.Message}");
                         }
                    }                    

                    logger.LogInformation($"MaxDop-Actually Used: {actualDop} Dataverse Server");
                    this.CreateMultipleInParallel(client, logger, actualDop, maxRetryCount);

                    //update tracking table if available
                    if(trackerEntity != null)
                    {   
                        try
                        {
                            trackerEntity[Constants.StatusColumn] = Constants.StatusValueComplete;
                            trackerEntity[Constants.IngestionEndColumn] = DateTime.Now;
                            client.Update(trackerEntity);
                            logger.LogInformation($"Updated tracker table: {Constants.UploadTable}, Id = {this.Params.UploadId}, Status = { Constants.StatusValueComplete}");
                        }
                        catch(Exception ex)
                        {
                            //trackerEntity fails
                            trackerEntity = null;
                            logger.LogError($"Error trying to update tracker entity. Ingestion will proceed without updating tracker. {ex.Message}");
                        }
                    }

                    logger.LogInformation($"RecordCreationCompleted:{stopWatch.Elapsed.TotalSeconds}-{activityId}-{totalRecords}");
                }

                stopWatch.Stop();                

                string endMessage = $"Ended-Watch {activityId} - CompletedProcessing: {totalRecords} in Hours: {stopWatch.Elapsed.Hours}:{stopWatch.Elapsed.Minutes} mins. Full Clock: {stopWatch.Elapsed.Duration()}";
                logger.LogInformation(endMessage);
                await Task.Yield();
            }
            catch (Exception e)
            {
                logger.LogError(e, "Do-Failed");
                throw;
            }
        }

        /// <summary>
        /// Create Record using "Create Multiple" Organization Request 
        /// </summary>
        /// <param name="serviceClient">Service Client (Dataverse SDK)</param>
        /// <param name="logger">ILogger Instance</param>
        /// <param name="customDop">Custom DOP</param>
        /// <param name="maxRetryCount">Max Retry Count</param>
        private void CreateMultipleInParallel(ServiceClient serviceClient, ILogger logger, int customDop, int maxRetryCount)
        {
            ParallelOptions parallelOptions = new ParallelOptions()
            {
                MaxDegreeOfParallelism = customDop == 0 ? serviceClient.RecommendedDegreesOfParallelism : customDop,
            };

            logger.LogInformation($"MaxDop returned by Dataverse: {serviceClient.RecommendedDegreesOfParallelism}");

            List<OrganizationRequest> createMultipleRequests = new List<OrganizationRequest>();

            List<List<Entity>> batchRecords = this.Params.Items.Split(this.Params.BatchSize);

            foreach (var localBatchPool in batchRecords)
            {
                //OrganizationRequest singleRequest = new OrganizationRequest(Constants.Message);

                EntityCollection localEntityCollection = new EntityCollection();
                localEntityCollection.EntityName = this.Params.TableLogicalName;

                localEntityCollection.Entities.AddRange(localBatchPool);

                CreateMultipleRequest createMultipleRequest = new()
                {
                    Targets = localEntityCollection,
                };

                //Turn Off Custom Plugin Execution. Default is False
                createMultipleRequest.Parameters[Constants.BypassCustomPluginExecution] = true;
                createMultipleRequests.Add(createMultipleRequest);                
            }
            logger.LogInformation($"CreateMultipleRequests - { createMultipleRequests.Count } created.");

            if (serviceClient.RetryPauseTime == default(TimeSpan))
            {
                serviceClient.RetryPauseTime = new TimeSpan(0, 0, 5);
            }

            if (serviceClient.MaxRetryCount == default(int))
            {
                serviceClient.MaxRetryCount = maxRetryCount;
            }

            Parallel.ForEach(createMultipleRequests, parallelOptions,
               () =>
               {
                   //Disable Sticky Session
                   serviceClient.EnableAffinityCookie = false;
                   return serviceClient.Clone();

               }, (batch, loopState, index, threadSafeClient) =>
               {
                   bool isProcessed = false;
                   int retryCount = 0;

                   do
                   {
                       try
                       {
                           CreateMultipleResponse response = (CreateMultipleResponse)threadSafeClient.Execute(batch);
                           logger.LogInformation($"Batch completed: {response.Ids.Length}");
                           isProcessed = true;
                           Entity progress = new Entity(Constants.UploadProgressTable);
                           progress[Constants.EntityAttributes.PartitionId] = this.Params.UploadId.ToString();
                           progress[Constants.EntityAttributes.TTLInSeconds] = Constants.DefaultTTLProgressInfo;
                           progress[Constants.EntityAttributes.TotalRows] = response.Ids.Length;
                           serviceClient.Create(progress);
                       }
                       catch (Exception ex)
                       {
                           retryCount++;
                           Task.Delay(10000 * retryCount); //Hard-Code Failures, 10 seconds per each cycle of retries (for 100 retries, up to 16 mins)
                       }
                   }

                   while (!isProcessed && retryCount <= threadSafeClient.MaxRetryCount);
                   return threadSafeClient;
               },
               (threadSafeLocalInstance) =>
               {
                   //Dispose the cloned serviceClient instance
                   if (threadSafeLocalInstance != null)
                   {
                       threadSafeLocalInstance.Dispose();
                   }
               });
        }
        private readonly Input Params;
    }

    public static class Extension
    {
        public static List<List<T>> Split<T>(this IEnumerable<T> collection, int size)
        {
            var split = new List<List<T>>();
            var count = 0;
            var temp = new List<T>();

            foreach (var element in collection)
            {
                if (count++ == size)
                {
                    split.Add(temp);
                    temp = new List<T>();
                    count = 1;
                }
                temp.Add(element);
            }
            split.Add(temp);

            return split;
        }
    }
}