﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVBulkInsertSample
{
    internal class Constants
    {        
        public const string BypassCustomPluginExecution = "BypassCustomPluginExecution";
        public const int DefaultTTL = 6000;
        public const int DefaultBatchSize = 500;
        public const int DefaultDoP = 50;
        public const int DefaultTTLProgressInfo = 14400; //4 hours (4 x 60 mins x 60 secs)
        public const string UploadTable = "cat_demoupload";
        public const string DefaultUploadIdColumn = "cat_demoupload";
        public const string StatusColumn = "cat_uploadstatus";
        public const string StatusValueComplete = "Completed";
        public const string StatusValueInserting = "Inserting records";
        public const string IngestionStartColumn = "cat_ingestionstart";
        public const string IngestionEndColumn = "cat_ingestionend";
        public const string UploadProgressTable = "cat_demouploadprogress";
        
        public class EntityAttributes
        {
            public const string UploadTotalRecords = "cat_totalrecords";
            public const string TTLInSeconds = "ttlinseconds";
            public const string PartitionId = "partitionid";
            public const string TotalRows = "cat_totalrows";
        }
    }
}
