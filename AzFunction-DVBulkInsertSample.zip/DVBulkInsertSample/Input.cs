﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Extensions.ObjectPool;

namespace DVBulkInsertSample
{
    internal class Input
    {
        private ILogger log;
        public Input(ILogger log) { this.log = log; }
        public Input(string clientId, string clientSecret, string tenantId, ILogger log)
        {
            this.ClientId = clientId;
            this.ClientSecret = clientSecret;
            this.TenantId = tenantId;
            this.log = log;
        }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string TenantId { get; set; }

        public string SiteId { get; set; }
        public string DriveId{ get; set; }
        public string FileName { get; set; }
        public string SheetName { get; set; }
        public string AddressRange { get; set; }

        public string AdditionalColumnNames { get; set; }

        public string AdditionalColumnValues { get; set; }
        public char ColumnValueDelimiter { get; set; }

        public Guid OnBehalfUserId {  get; set; }

        public int DoP { get; set; }

        public string OrgUrl {  get; set; }
        //public string TableSetName { get; set; }
        public string TableLogicalName { get; set; }
             
        public int BatchSize { get; set; }

        public int RowOffset { get; set; }
        public int TTL { get; set; }

        public string[] TableColumns { get; set; }

        //public string LookUpTableLogicalName { get; set; }
        public string LookUpColumnName { get; set; }
        public Guid UploadId { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        public List<Entity> Items { get; set; }

        public async Task<string> GetExcelData(ILogger log)
        {
            string itemId;
            string excelData = string.Empty;
            log.LogInformation($"GetExcelData: Attempting to get access token.");

            string accessToken = await this.GetAccessTokenAsync();

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                //get item id first
                HttpResponseMessage response = await client.GetAsync(
                    $"https://graph.microsoft.com/v1.0/sites/{this.SiteId}/drives/{this.DriveId}/root:/{this.FileName}?$select=id"
                );
                if (response.IsSuccessStatusCode)
                {
                    string responseBody = await response.Content.ReadAsStringAsync();                    
                    itemId = JsonDocument.Parse(responseBody).RootElement.GetProperty("id").GetString();
                    log.LogInformation($"Graph API - getting item Id completed. Id = { itemId }");

                    //if no address specified, get all range
                    if (string.IsNullOrEmpty(this.AddressRange))
                    {
                        response = await client.GetAsync($"https://graph.microsoft.com/v1.0/sites/{this.SiteId}/drives/{this.DriveId}/items/{itemId}/workbook/worksheets/{this.SheetName}/range/usedRange(valuesOnly=true)?$select=address,columnCount,cellCount");
                        responseBody = await response.Content.ReadAsStringAsync();
                        log.LogInformation($"Graph API - get usedrange completed.");

                        var sheetPropElement = JsonDocument.Parse(responseBody).RootElement;                                      
                        log.LogInformation($"Total rows: {(sheetPropElement.GetProperty("cellCount").GetInt32() / sheetPropElement.GetProperty("columnCount").GetInt32()) - this.RowOffset}");
                        string rawAddressRange = sheetPropElement.GetProperty("address").GetString().Split('!').TakeLast(1).FirstOrDefault("A1:I10");
                        log.LogInformation($"Address: {rawAddressRange}");

                        //change range based on row offset
                        string[] rangeParts = rawAddressRange.Split(":");

                        Match startRow = Regex.Match(rangeParts[0], @"\d+");
                        this.AddressRange = $"{rangeParts[0].Replace(startRow.Value, (int.Parse(startRow.Value) + 1).ToString())}:{ rangeParts[1]}";
                        //log.LogInformation($"Adjusted address from offset {this.RowOffset}: {this.AddressRange}");
                    }

                    //get excel data
                    response = await client.GetAsync(
                        $"https://graph.microsoft.com/v1.0/sites/{this.SiteId}/drives/{this.DriveId}/items/{ itemId}/workbook/worksheets/{this.SheetName}/range(address='{this.AddressRange}')?$select=text"
                    );
                    if (response.IsSuccessStatusCode)
                    {
                        responseBody = await response.Content.ReadAsStringAsync();
                        log.LogInformation($"Graph API - get rows completed.");
                        excelData = JsonDocument.Parse(responseBody).RootElement.GetProperty("text").ToString();
                        log.LogInformation($"Excel Data loaded.");
                    }
                    else
                    {
                        log.LogError($"Graph API request failed: {response.ReasonPhrase}");
                    }
                }                
            }
            return excelData;
        }

        private async Task<string> GetAccessTokenAsync()
        {
            using (HttpClient client = new HttpClient())
            {
                string tokenEndpoint = $"https://login.microsoftonline.com/{ this.TenantId}/oauth2/token";
                var content = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("grant_type", "client_credentials"),
                    new KeyValuePair<string, string>("client_id", this.ClientId),
                    new KeyValuePair<string, string>("client_secret", this.ClientSecret),
                    new KeyValuePair<string, string>("resource", "https://graph.microsoft.com")
                });
                HttpResponseMessage response = await client.PostAsync(tokenEndpoint, content);
                if (response.IsSuccessStatusCode)
                {
                    string responseBody = await response.Content.ReadAsStringAsync();
                    log.LogInformation($"Get access token completed.");
                    return JsonDocument.Parse(responseBody).RootElement.GetProperty("access_token").GetString();
                }
                else
                {
                    log.LogError($"GetAccessToken failed - { response.ReasonPhrase }");
                    throw new Exception($"Failed to acquire access token: {response.ReasonPhrase}");
                }
            }
        }
    }
}
