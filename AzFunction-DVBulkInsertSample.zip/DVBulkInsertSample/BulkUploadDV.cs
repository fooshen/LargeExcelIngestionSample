using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Linq;
using System.Collections.Generic;
using System.Text.Json;
using Microsoft.Xrm.Sdk;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using System.Net.Http.Json;

namespace DVBulkInsertSample
{
    public static class BulkUploadDV
    {
        [FunctionName("BulkUploadDV")]
        public static async Task<HttpResponseMessage> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            Input input = new Input(log);
            input.ClientId = GetHeaderValue(ref req, "ClientId");
            input.ClientSecret = GetHeaderValue(ref req, "ClientSecret");
            input.TenantId = GetHeaderValue(ref req, "TenantId");   
            input.OrgUrl = GetHeaderValue(ref req, "OrgUrl");
            input.TableLogicalName = GetHeaderValue(ref req, "TableLogicalName");
            input.TableColumns = GetHeaderValue(ref req, "TableColumns", "").Split(",");
             
            input.SiteId = GetHeaderValue(ref req, "SiteId");
            input.DriveId = GetHeaderValue(ref req, "DriveId");
            input.FileName = GetHeaderValue(ref req, "FileName");

            input.SheetName = GetHeaderValue(ref req, "SheetName", Constants.DefaultSheetName);
            input.AddressRange = GetHeaderValue(ref req, "AddressRange");
            input.RowOffset = int.Parse(GetHeaderValue(ref req, "RowOffset", "1"));

            input.DoP = int.Parse(GetHeaderValue(ref req, "DoP", Constants.DefaultDoP.ToString()));
            input.BatchSize = int.Parse(GetHeaderValue(ref req, "BatchSize", Constants.DefaultBatchSize.ToString()));
            input.TTL = int.Parse(GetHeaderValue(ref req, "TTL", Constants.DefaultTTL.ToString()));

            input.LookUpColumnName = GetHeaderValue(ref req, "LookUpColumnName", Constants.DefaultUploadIdColumn);
            input.UploadId = new Guid(GetHeaderValue(ref req, "UploadId"));

            input.AdditionalColumnNames = GetHeaderValue(ref req, "AdditionalColumnNames", "");
            input.AdditionalColumnValues = GetHeaderValue(ref req, "AdditionalColumnValues", "");
            input.ColumnValueDelimiter = GetHeaderValue(ref req, "ColumnValueDelimiter", "|").ToCharArray()[0];

            var onBehalf = GetHeaderValue(ref req, "OnBehalfUserId", "");
            if (!String.IsNullOrEmpty(onBehalf)) input.OnBehalfUserId = Guid.Parse(onBehalf);
            
            log.LogInformation($"Input received: { JsonConvert.SerializeObject(input) } ");

            string excelData = await input.GetExcelData(log);

            input.Items = new List<Entity>();
            // Parse the JSON array using JsonDocument
            using (JsonDocument document = JsonDocument.Parse(excelData))
            {   
                // Process each element in the JSON array
                foreach (JsonElement element in document.RootElement.EnumerateArray())
                {
                    if (element.ValueKind == JsonValueKind.Array)
                    {
                        Entity demoItem = new Entity(input.TableLogicalName);

                        for(int i = 0; i <= input.TableColumns.Length - 1; i++)
                        {
                            demoItem[input.TableColumns[i]] = element[i].GetString();
                        }
                        
                        demoItem[Constants.EntityAttributes.TTLInSeconds] = input.TTL == 0 ? Constants.DefaultTTL: input.TTL;

                        if (!String.IsNullOrEmpty(input.LookUpColumnName))
                        {
                            demoItem[input.LookUpColumnName] = new EntityReference { Id = input.UploadId, LogicalName = Constants.UploadTable };
                        }

                        //add additional column names and static values, if provided
                        if (!String.IsNullOrEmpty(input.AdditionalColumnNames))
                        {
                            string[] colNames = input.AdditionalColumnNames.Split(',');
                            string[] colValues = input.AdditionalColumnValues.Split(input.ColumnValueDelimiter);
                            if(colNames.Length == colValues.Length)
                            {
                                for(int i = 0; i < colNames.Length; i++)
                                {
                                    demoItem[colNames[i]] = colValues[i];
                                }
                            }
                        }

                        if(!String.IsNullOrEmpty(onBehalf))
                        {
                            demoItem[Constants.EntityAttributes.CreatedOnBehalfBy] =
                                new EntityReference { Id = input.OnBehalfUserId, LogicalName = Constants.SystemUserTable };
                        }

                        input.Items.Add(demoItem);
                    }
                }
            }

            Dataverse dv = new Dataverse(input);
            dv.DoInternalAsync(log, Guid.NewGuid().ToString(), 5);
            log.LogInformation("Responded.");
            return new HttpResponseMessage(System.Net.HttpStatusCode.Accepted);            
        }

        private static string GetHeaderValue(ref HttpRequest req, string header)
        {
            return GetHeaderValue(ref req, header, "");
        }
        private static string GetHeaderValue(ref HttpRequest req, string header, string defaultValue)
        {
            string result = defaultValue;
            if (req.Headers.TryGetValue(header, out var headerValue))
            {
                result = headerValue.FirstOrDefault(defaultValue);
            }
            return result;
        }
    }
}
